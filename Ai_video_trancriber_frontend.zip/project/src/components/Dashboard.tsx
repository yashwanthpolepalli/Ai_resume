import React, { useState } from 'react';
import { Play, Upload, FileText, CheckCircle, AlertCircle, BarChart3, Video, Code, TestTube, Clock, Download } from 'lucide-react';

interface TestCase {
  id: string;
  name: string;
  type: string;
  status: 'pending' | 'running' | 'passed' | 'failed';
  duration?: number;
}

interface TestResult {
  id: string;
  testName: string;
  status: 'passed' | 'failed';
  duration: number;
  screenshot?: string;
  error?: string;
}

const Dashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('upload');
  const [videoProcessing, setVideoProcessing] = useState(false);
  const [testCasesGenerated, setTestCasesGenerated] = useState(false);
  const [testsRunning, setTestsRunning] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);

  const mockTestCases: TestCase[] = [
    { id: '1', name: 'User Registration Flow', type: 'Core User Flow', status: 'passed', duration: 2340 },
    { id: '2', name: 'Login with Invalid Credentials', type: 'Edge Case', status: 'passed', duration: 1200 },
    { id: '3', name: 'Profile Update Validation', type: 'Form Validation', status: 'failed', duration: 1800 },
    { id: '4', name: 'Mobile Responsive Navigation', type: 'Cross-browser', status: 'passed', duration: 3100 },
    { id: '5', name: 'Accessibility - Screen Reader', type: 'Accessibility', status: 'passed', duration: 2800 },
    { id: '6', name: 'Performance - Page Load Time', type: 'Performance', status: 'passed', duration: 4200 },
  ];

  const mockResults: TestResult[] = [
    { id: '1', testName: 'User Registration Flow', status: 'passed', duration: 2340 },
    { id: '2', testName: 'Login with Invalid Credentials', status: 'passed', duration: 1200 },
    { id: '3', testName: 'Profile Update Validation', status: 'failed', duration: 1800, error: 'Element not found: #submit-button' },
    { id: '4', testName: 'Mobile Responsive Navigation', status: 'passed', duration: 3100 },
    { id: '5', testName: 'Accessibility - Screen Reader', status: 'passed', duration: 2800 },
    { id: '6', testName: 'Performance - Page Load Time', status: 'passed', duration: 4200 },
  ];

  const handleVideoUpload = () => {
    setVideoProcessing(true);
    setCurrentStep(2);
    setTimeout(() => {
      setVideoProcessing(false);
      setCurrentStep(3);
    }, 3000);
  };

  const handleGenerateTests = () => {
    setTestCasesGenerated(true);
    setCurrentStep(4);
  };

  const handleRunTests = () => {
    setTestsRunning(true);
    setCurrentStep(5);
    setTimeout(() => {
      setTestsRunning(false);
      setActiveTab('results');
    }, 4000);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'passed':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'failed':
        return <AlertCircle className="w-5 h-5 text-red-500" />;
      case 'running':
        return <Clock className="w-5 h-5 text-blue-500 animate-spin" />;
      default:
        return <Clock className="w-5 h-5 text-gray-400" />;
    }
  };

  const TabButton: React.FC<{ id: string; label: string; icon: React.ReactNode; active: boolean }> = ({ id, label, icon, active }) => (
    <button
      onClick={() => setActiveTab(id)}
      className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
        active
          ? 'bg-blue-600 text-white shadow-lg'
          : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-200'
      }`}
    >
      {icon}
      <span>{label}</span>
    </button>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <TestTube className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">AI QA Agent</h1>
                <p className="text-sm text-gray-500">Automated Frontend Testing Platform</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900">Recruiter.ai Project</p>
                <p className="text-xs text-gray-500">Last updated: 2 minutes ago</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Progress Steps */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex items-center justify-between mb-8">
          {[
            { step: 1, label: 'Upload Video', icon: Video },
            { step: 2, label: 'Process Content', icon: Play },
            { step: 3, label: 'Generate Tests', icon: FileText },
            { step: 4, label: 'Convert Scripts', icon: Code },
            { step: 5, label: 'Execute Tests', icon: TestTube },
          ].map(({ step, label, icon: Icon }, index) => (
            <div key={step} className="flex items-center">
              <div className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${
                currentStep >= step
                  ? 'bg-blue-600 border-blue-600 text-white'
                  : 'bg-white border-gray-300 text-gray-400'
              }`}>
                <Icon className="w-5 h-5" />
              </div>
              <span className={`ml-2 text-sm font-medium ${
                currentStep >= step ? 'text-blue-600' : 'text-gray-400'
              }`}>
                {label}
              </span>
              {index < 4 && (
                <div className={`w-16 h-0.5 mx-4 ${
                  currentStep > step ? 'bg-blue-600' : 'bg-gray-300'
                }`} />
              )}
            </div>
          ))}
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-4 mb-6">
          <TabButton id="upload" label="Video Upload" icon={<Upload className="w-4 h-4" />} active={activeTab === 'upload'} />
          <TabButton id="generation" label="Test Generation" icon={<FileText className="w-4 h-4" />} active={activeTab === 'generation'} />
          <TabButton id="execution" label="Test Execution" icon={<Play className="w-4 h-4" />} active={activeTab === 'execution'} />
          <TabButton id="results" label="Results & Reports" icon={<BarChart3 className="w-4 h-4" />} active={activeTab === 'results'} />
        </div>

        {/* Content Area */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          {activeTab === 'upload' && (
            <div className="p-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-6">Video Content Processing</h2>
              
              {!videoProcessing ? (
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-12 text-center hover:border-blue-400 transition-colors duration-200">
                  <Video className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Upload Recruiter.ai Tutorial Video</h3>
                  <p className="text-gray-500 mb-6">Drop your how-to video here or click to browse</p>
                  <button
                    onClick={handleVideoUpload}
                    className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors duration-200 inline-flex items-center space-x-2"
                  >
                    <Upload className="w-4 h-4" />
                    <span>Upload Video</span>
                  </button>
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="animate-spin w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-4"></div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Processing Video Content</h3>
                  <p className="text-gray-500">Extracting transcriptions and segmenting steps...</p>
                </div>
              )}

              {currentStep >= 3 && (
                <div className="mt-8 p-6 bg-green-50 rounded-lg border border-green-200">
                  <div className="flex items-center space-x-3 mb-4">
                    <CheckCircle className="w-6 h-6 text-green-600" />
                    <h4 className="text-lg font-medium text-green-900">Video Processing Complete</h4>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-green-800 font-medium">Transcript Extracted:</p>
                      <p className="text-green-700">• User registration workflow identified</p>
                      <p className="text-green-700">• Form validation steps detected</p>
                      <p className="text-green-700">• Navigation patterns analyzed</p>
                    </div>
                    <div>
                      <p className="text-green-800 font-medium">Content Segmented:</p>
                      <p className="text-green-700">• 12 key user interactions</p>
                      <p className="text-green-700">• 8 form submission scenarios</p>
                      <p className="text-green-700">• 6 error handling cases</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'generation' && (
            <div className="p-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-gray-900">Test Case Generation</h2>
                {!testCasesGenerated && currentStep >= 3 && (
                  <button
                    onClick={handleGenerateTests}
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200 inline-flex items-center space-x-2"
                  >
                    <FileText className="w-4 h-4" />
                    <span>Generate Test Cases</span>
                  </button>
                )}
              </div>

              {testCasesGenerated ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                      <h4 className="font-medium text-blue-900 mb-1">Core Flows</h4>
                      <p className="text-2xl font-bold text-blue-600">4</p>
                      <p className="text-sm text-blue-700">User journeys</p>
                    </div>
                    <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
                      <h4 className="font-medium text-orange-900 mb-1">Edge Cases</h4>
                      <p className="text-2xl font-bold text-orange-600">8</p>
                      <p className="text-sm text-orange-700">Boundary conditions</p>
                    </div>
                    <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                      <h4 className="font-medium text-green-900 mb-1">Accessibility</h4>
                      <p className="text-2xl font-bold text-green-600">6</p>
                      <p className="text-sm text-green-700">A11y checks</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    {mockTestCases.map((testCase) => (
                      <div key={testCase.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors duration-200">
                        <div className="flex items-center space-x-4">
                          {getStatusIcon(testCase.status)}
                          <div>
                            <h4 className="font-medium text-gray-900">{testCase.name}</h4>
                            <p className="text-sm text-gray-500">{testCase.type}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-4">
                          {testCase.duration && (
                            <span className="text-sm text-gray-500">{testCase.duration}ms</span>
                          )}
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            testCase.status === 'passed' ? 'bg-green-100 text-green-800' :
                            testCase.status === 'failed' ? 'bg-red-100 text-red-800' :
                            'bg-gray-100 text-gray-800'
                          }`}>
                            {testCase.status}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center py-12">
                  <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Ready to Generate Test Cases</h3>
                  <p className="text-gray-500">AI will analyze the video content and create comprehensive test scenarios</p>
                </div>
              )}
            </div>
          )}

          {activeTab === 'execution' && (
            <div className="p-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-gray-900">Test Execution</h2>
                {testCasesGenerated && !testsRunning && (
                  <button
                    onClick={handleRunTests}
                    className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors duration-200 inline-flex items-center space-x-2"
                  >
                    <Play className="w-4 h-4" />
                    <span>Run All Tests</span>
                  </button>
                )}
              </div>

              {testsRunning ? (
                <div className="space-y-4">
                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-200 mb-6">
                    <div className="flex items-center space-x-3 mb-2">
                      <div className="animate-spin w-5 h-5 border-2 border-blue-600 border-t-transparent rounded-full"></div>
                      <h4 className="font-medium text-blue-900">Executing Playwright Tests</h4>
                    </div>
                    <p className="text-sm text-blue-700">Running tests across multiple browsers and devices...</p>
                  </div>

                  {mockTestCases.map((testCase, index) => (
                    <div key={testCase.id} className={`p-4 border rounded-lg transition-all duration-500 ${
                      index < 3 ? 'border-green-200 bg-green-50' :
                      index === 3 ? 'border-blue-200 bg-blue-50' :
                      'border-gray-200 bg-gray-50'
                    }`}>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          {index < 3 ? <CheckCircle className="w-5 h-5 text-green-500" /> :
                           index === 3 ? <div className="animate-spin w-5 h-5 border-2 border-blue-600 border-t-transparent rounded-full"></div> :
                           <Clock className="w-5 h-5 text-gray-400" />}
                          <span className="font-medium text-gray-900">{testCase.name}</span>
                        </div>
                        <span className={`text-sm ${
                          index < 3 ? 'text-green-600' :
                          index === 3 ? 'text-blue-600' :
                          'text-gray-500'
                        }`}>
                          {index < 3 ? 'Completed' :
                           index === 3 ? 'Running...' :
                           'Pending'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : testCasesGenerated ? (
                <div className="text-center py-12">
                  <TestTube className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Ready to Execute Tests</h3>
                  <p className="text-gray-500">Click "Run All Tests" to start the Playwright test execution</p>
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <TestTube className="w-8 h-8 text-gray-400" />
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Test Cases Required</h3>
                  <p className="text-gray-500">Generate test cases first before executing tests</p>
                </div>
              )}
            </div>
          )}

          {activeTab === 'results' && (
            <div className="p-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-gray-900">Test Results & Reports</h2>
                <div className="flex space-x-3">
                  <button className="text-blue-600 hover:text-blue-700 inline-flex items-center space-x-1">
                    <Download className="w-4 h-4" />
                    <span>Export Report</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                <div className="bg-green-50 p-6 rounded-lg border border-green-200">
                  <h4 className="text-sm font-medium text-green-900 mb-1">Passed</h4>
                  <p className="text-3xl font-bold text-green-600">5</p>
                  <p className="text-sm text-green-700">83.3% success rate</p>
                </div>
                <div className="bg-red-50 p-6 rounded-lg border border-red-200">
                  <h4 className="text-sm font-medium text-red-900 mb-1">Failed</h4>
                  <p className="text-3xl font-bold text-red-600">1</p>
                  <p className="text-sm text-red-700">Needs attention</p>
                </div>
                <div className="bg-blue-50 p-6 rounded-lg border border-blue-200">
                  <h4 className="text-sm font-medium text-blue-900 mb-1">Total Time</h4>
                  <p className="text-3xl font-bold text-blue-600">15.4s</p>
                  <p className="text-sm text-blue-700">Average execution</p>
                </div>
                <div className="bg-purple-50 p-6 rounded-lg border border-purple-200">
                  <h4 className="text-sm font-medium text-purple-900 mb-1">Coverage</h4>
                  <p className="text-3xl font-bold text-purple-600">94%</p>
                  <p className="text-sm text-purple-700">Code coverage</p>
                </div>
              </div>

              <div className="space-y-4">
                {mockResults.map((result) => (
                  <div key={result.id} className="border border-gray-200 rounded-lg p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        {getStatusIcon(result.status)}
                        <h4 className="font-medium text-gray-900">{result.testName}</h4>
                      </div>
                      <div className="flex items-center space-x-4">
                        <span className="text-sm text-gray-500">{result.duration}ms</span>
                        <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                          result.status === 'passed' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {result.status}
                        </span>
                      </div>
                    </div>
                    
                    {result.error && (
                      <div className="bg-red-50 p-3 rounded border border-red-200">
                        <p className="text-sm text-red-800 font-mono">{result.error}</p>
                      </div>
                    )}
                    
                    <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                      <div>
                        <p className="text-gray-500 font-medium">Browser:</p>
                        <p className="text-gray-900">Chrome 120.0</p>
                      </div>
                      <div>
                        <p className="text-gray-500 font-medium">Viewport:</p>
                        <p className="text-gray-900">1920x1080</p>
                      </div>
                      <div>
                        <p className="text-gray-500 font-medium">User Agent:</p>
                        <p className="text-gray-900">Desktop</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;